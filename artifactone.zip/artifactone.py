Python 3.6.6 (v3.6.6:4cf1f54eb7, Jun 27 2018, 03:37:03) [MSC v.1900 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> #-----------------------------------------------------------------------------------#
#Project: ePortfolio Artifact One: Software Design/Engineering                      #
#Author: Alexander Varljen                                                          #
#Description: This is a remake of my CS 210 Final project two, which was a banking  # 
#app that took a users intial payment amount, a monthly deposit amount, and annual  #
#interest, and calculated the year end balance based on these values and the number # 
#of years that the user entered to see.                                             #
#-----------------------------------------------------------------------------------#
import os #For the "clear screen" function

user_input = ' '

#This user defined function clears the screen when called upon
def screen_clear():
    if os.name == 'posix':
        _ = os.system('clear')
    else:
        _ = os.system('cls')
    print('')

#Here is a user defined function for the first user input
def C_ToContinue():
    user_input = input("Press 'c' to continue...")
    return user_input

#Here is the first menu that pops up on the screen
while user_input != 'c':
    SymbolA = '*'

    print(SymbolA*30)
    print('Year End Balance Calculation Menu')
    print(SymbolA*30)
    #The next four print statements display the options that the customers will have.
    print('Initial Investment Amount: ')
    print('Monthly Deposit (zero or more): ')
    print('Annual Interest: ')
    print('Number of Years (1-5): ')
    user_input = C_ToContinue()

#Function for quiting app input
def Q_ToQuit():
    user_input = input('Press "q" to quit.')
    return user_input

#Function for intitial investment input
def Initial_Investment_Amount():
    InitialIA = float(input())
    if InitialIA <= 0: #There has to be an initial investment.
        raise ValueError('Invalid initial investment')
    return InitialIA

#function for monthly deposit input
def Monthly_Deposit():
    monthly = float(input())
    if monthly < 0: #There can't be a negative monthly deposit.
        raise ValueError('Invalid monthly deposit')
    return monthly

#function for annual interest input
def Annual_Interst(): 
    annualI = float(input())
    if annualI <= 0: #annual interest can't be zero or less than zero for the calculations.
        raise ValueError('Invalid interest rate')
    return annualI

#function for number of years to be calculated input 
def Num_Of_Years():
    numOfYears = int(input())  
    if numOfYears <= 0: #No change in the balance can be calculated if the number of years are zero.
        raise ValueError('Invalid number of years')
    if numOfYears > 5: #The calculations don't deal with values beyond five years.
        raise ValueError('Invalid number of years')
    return numOfYears

#This prints out a menu that reads user input and prints the output display for the calculated changes to the
#customers balance.
while user_input != 'q':

    #Clearing the screen for the new output.
    screen_clear()
    
    print(SymbolA*26)
    print(SymbolA*11, 'Data Input', SymbolA*13)

    #Calling on try catch input functions
    try: 
        print('Initial Investment Amount: ')
        InitialIA = Initial_Investment_Amount()
        print('Monthly Deposit (zero or more): ')
        monthly = Monthly_Deposit()
        print('Annual Interest: ')
        annualI = Annual_Interst()
        print('Number of Years (1-5): ')
        numOfYears = Num_Of_Years()
    #Throws exceptions from input fucntions if values could present calculation problems.
    except ValueError as excpt:
        print(excpt)
        print('These values can\'t be calculated.')
    
    SymbolB = '-' #"SymbolA" and "SymbolB" are lines or spaces that will be used in the output display.
    SymbolC = ' '

    #Clearing the screen for the new output.
    screen_clear()
    
    #Values for bank balance calculations are calculated and printed based on the 
    #number of years that the customer wants to see.

    #These are for those without monthly deposits.
    if monthly == 0:
        #Printing out the Calculated Output Screen.
        print('Balance and Interest Without Additional Monthly Deposts')
        print(SymbolB*30)
        print(SymbolB*30)
        print('Year', SymbolC, 'Year End Balance', SymbolC, 'Year End Interest')

        try:
            #New variables created from input variables are denoted by "...wM", which means 
            #without montlhy, for the calculations where no monthly deposit are made.

            if numOfYears == 1: #taken from the input method for number of years.
                #Calculations for one year of change in year end ballance and year end interest. 

                #"IntialIA" is the intitial investment variable from our initial investment input method.
                #"annualI" is the annual interest varaible from the annual interest input method.
                interestwM = InitialIA * ((annualI / 100) / 12) #"interestwM" is the calculated interest for one year.
                yearEndBalwM = InitialIA + interestwM #"yearEndBalwM" is calculated year end balance for one year.
                yearEndIntwM = interestwM #"yearEndIntwM" is the calculated year end intest for one year.

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for one year of change.
                print('1', SymbolC*3, '$', yearEndBalwM, SymbolC*5, yearEndIntwM)

            elif numOfYears == 2:
                #Calculations for two years of change in year end ballance and year end interest. 

                #Next three lines are the same as the calculations from "if numOfYears == 1".
                interestwM = InitialIA * ((annualI / 100) / 12)
                yearEndBalwM = InitialIA + interestwM
                yearEndIntwM = interestwM

                #This is for the calculations of year end balance and year end interest after two years.
                #Here, the calculation construction is the same for one year, but the calculations from 
                #the first year are added
                interestwM2 = InitialIA * ((annualI / 100) / 12) + interestwM #"interestwM2" is calculated interest for two years.
                yearEndBalwM2 = InitialIA + interestwM2 + yearEndBalwM #"yearEndBalwM2" is calculated year end balance for two years.
                yearEndIntwM2 = interestwM2 + interestwM #"yearEndIntwM2" is the calculated year end intest for two years.

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for two years of change.
                print('1', SymbolC*3, '$', yearEndBalwM, SymbolC*5, yearEndIntwM)
                print('2', SymbolC*3, '$', yearEndBalwM2, SymbolC*5, yearEndIntwM2)

            elif numOfYears == 3:
                #Calculations for three years of change in year end ballance and year end interest. 

                #Next three lines are the same as the calculations from "if numOfYears == 1".
                interestwM = InitialIA * ((annualI / 100) / 12)
                yearEndBalwM = InitialIA + interestwM
                yearEndIntwM = interestwM

                #Next three lines are the same as the calculations from "if numOfYears == 2".
                interestwM2 = InitialIA * ((annualI / 100) / 12) + interestwM
                yearEndBalwM2 = InitialIA + interestwM2 + yearEndBalwM
                yearEndIntwM2 = interestwM2 + interestwM

                #Year end balance and interest calculations after three years of change in the balance.
                interestwM3 = InitialIA * ((annualI / 100) / 12) + interestwM2 #"interestwM3" is calculated interest for three years.
                yearEndBalwM3 = InitialIA + interestwM3 + yearEndBalwM2 #"yearEndBalwM3" is calculated year end balance for three years.
                yearEndIntwM3 = interestwM3 + interestwM2 #"yearEndIntwM3" is the calculated year end intest for three years.           

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for three years of change.
                print('1', SymbolC*3, '$', yearEndBalwM, SymbolC*5, yearEndIntwM)
                print('2', SymbolC*3, '$', yearEndBalwM2, SymbolC*5, yearEndIntwM2)
                print('3', SymbolC*3, '$', yearEndBalwM3, SymbolC*5, yearEndIntwM3)

            elif numOfYears == 4:
                #Calculations for four years of change in year end ballance and year end interest. 

                #Next three lines are the same as the calculations from "if numOfYears == 1".
                interestwM = InitialIA * ((annualI / 100) / 12)
                yearEndBalwM = InitialIA + interestwM
                yearEndIntwM = interestwM

                #Next three lines are the same as the calculations from "if numOfYears == 2".
                interestwM2 = InitialIA * ((annualI / 100) / 12) + interestwM
                yearEndBalwM2 = InitialIA + interestwM2 + yearEndBalwM
                yearEndIntwM2 = interestwM2 + interestwM

                #Next three lines are the same as the calculations from "if numOfYears == 3".
                interestwM3 = InitialIA * ((annualI / 100) / 12) + interestwM2
                yearEndBalwM3 = InitialIA + interestwM3 + yearEndBalwM2
                yearEndIntwM3 = interestwM3 + interestwM2

                #Year end balance and interest calculations after four years of change in the balance.
                interestwM4 = InitialIA * ((annualI / 100) / 12) + interestwM3 #"interestwM4" is calculated interest for four years.
                yearEndBalwM4 = InitialIA + interestwM4 + yearEndBalwM3 #"yearEndBalwM4" is calculated year end balance for four years.
                yearEndIntwM4 = interestwM4 + interestwM3 #"yearEndIntwM4" is the calculated year end intest for four years.

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for four years of change.
                print('1', SymbolC*3, '$', yearEndBalwM, SymbolC*5, yearEndIntwM)
                print('2', SymbolC*3, '$', yearEndBalwM2, SymbolC*5, yearEndIntwM2)
                print('3', SymbolC*3, '$', yearEndBalwM3, SymbolC*5, yearEndIntwM3)
                print('4', SymbolC*3, '$', yearEndBalwM4, SymbolC*5, yearEndIntwM4)
            elif numOfYears == 5:
                #Calculations for five years of change in year end ballance and year end interest. 

                #Next three lines are the same as the calculations from "if numOfYears == 1".
                interestwM = InitialIA * ((annualI / 100) / 12)
                yearEndBalwM = InitialIA + interestwM
                yearEndIntwM = interestwM

                #Next three lines are the same as the calculations from "if numOfYears == 2".
                interestwM2 = InitialIA * ((annualI / 100) / 12) + interestwM
                yearEndBalwM2 = InitialIA + interestwM2 + yearEndBalwM
                yearEndIntwM2 = interestwM2 + interestwM

                #Next three lines are the same as the calculations from "if numOfYears == 3".
                interestwM3 = InitialIA * ((annualI / 100) / 12) + interestwM2
                yearEndBalwM3 = InitialIA + interestwM3 + yearEndBalwM2
                yearEndIntwM3 = interestwM3 + interestwM2

                #Next three lines are the same as the calculations from "if numOfYears == 4".
                interestwM4 = InitialIA * ((annualI / 100) / 12) + interestwM3
                yearEndBalwM4 = InitialIA + interestwM4 + yearEndBalwM3
                yearEndIntwM4 = interestwM4 + interestwM3

                #Year end balance and interest calculations after five years of change in the balance.
                interestwM5 = InitialIA * ((annualI / 100) / 12) + interestwM3 #"interestwM5" is calculated interest for five years.
                yearEndBalwM5 = InitialIA + interestwM4 + yearEndBalwM3 #"yearEndBalwM5" is calculated year end balance for five years.
                yearEndIntwM5 = interestwM4 + interestwM3 #"yearEndIntwM5" is the calculated year end intest for five years.

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for five years of change.
                print('1', SymbolC*3, '$', yearEndBalwM, SymbolC*5, yearEndIntwM)
                print('2', SymbolC*3, '$', yearEndBalwM2, SymbolC*5, yearEndIntwM2)
                print('3', SymbolC*3, '$', yearEndBalwM3, SymbolC*5, yearEndIntwM3)
                print('4', SymbolC*3, '$', yearEndBalwM4, SymbolC*5, yearEndIntwM4)
                print('5', SymbolC*3, '$', yearEndBalwM5, SymbolC*5, yearEndIntwM5)
            else:
                print("Sorry. Invalid number of years.") #For number of years inputs beyond five.
        except:
            #In case a bug or error in calculating the values occures. 
            print('Sorry, there was a problem claculating. Please try again')
    else:
        #If there is positive input for the monthly deposit, this message prints, and the code under the next if
        #statement "if monthly > 0" runs.
        print('Monthly Deposit Chosen')
    
    print(SymbolB*30)
    print(SymbolB*30)

    #Printed calculations if customers have monthly deposits. This if statement does not apply if there are
    #no monthly deposits. 
    if monthly > 0:
        #Values for bank balance calculations are calculated and printed based on the 
        #number of years. These are for with monthly deposits. 
        print('Balance and Interest With Additional Monthly Deposts')
        print(SymbolB*30)
        print(SymbolB*30)
        print('Year', SymbolC, 'Year End Balance', SymbolC, 'Year End Interest')

        try:
            if numOfYears == 1: #taken from the input method for number of years.
                #Calculations for one year of change in year end ballance and year end interest. 

                #"IntialIA" is the intitial investment variable from our initial investment input method.
                #"annualI" is the annual interest varaible from the annual interest input method.
                #"monthly" is the monthly deposit amount variable from the monthly deposit input method. 
                interest = (InitialIA * monthly) * ((annualI / 100) / 12) #"interest" is the calculated interest for one year.
                yearEndBal = (InitialIA * monthly) + interest #"yearEndBal" is calculated year end balance for one year.
                yearEndInt = interest #"yearEndInt" is the calculated year end intest for one year.

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for one year of change.
                print('1', SymbolC*3, '$', yearEndBal, SymbolC*5, yearEndInt)

            elif numOfYears == 2:
                #Calculations for two years of change in year end ballance and year end interest. 

                #Next three lines are the same as the calculations from "if numOfYears == 1".
                interest = (InitialIA * monthly) * ((annualI / 100) / 12) 
                yearEndBal = (InitialIA * monthly) + interest
                yearEndInt = interest

                #Year end balance and interest calculations after two years of change in the balance.
                interest2 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest #"interest2" is the calculated interest for two years.
                yearEndBal2 = (InitialIA * monthly) + interest2 + yearEndBal #"yearEndBal2" is calculated year end balance for fwo years.
                yearEndInt2 = interest2 + interest #"yearEndInt2" is the calculated year end intest for two years.

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for two years of change.
                print('1', SymbolC*3, '$', yearEndBal, SymbolC*5, yearEndInt)
                print('2', SymbolC*3, '$', yearEndBal2, SymbolC*5, yearEndInt2)

            elif numOfYears == 3:
                #Calculations for three years of change in year end ballance and year end interest. 

                #Next three lines are the same as the calculations from "if numOfYears == 1".
                interest = (InitialIA * monthly) * ((annualI / 100) / 12)
                yearEndBal = (InitialIA * monthly) + interest
                yearEndInt = interest

                #Next three lines are the same as the calculations from "if numOfYears == 2".
                interest2 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest
                yearEndBal2 = (InitialIA * monthly) + interest2 + yearEndBal
                yearEndInt2 = interest2 + interest

                #Year end balance and interest calculations after three years of change in the balance.
                interest3 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest2 #"interest3" is the calculated interest for three years.
                yearEndBal3 = (InitialIA * monthly) + interest3 + yearEndBal2 #"yearEndBal3" is calculated year end balance for three years.
                yearEndInt3 = interest3 + interest2 #"yearEndInt3" is the calculated year end intest for three years.

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for three years of change.
                print('1', SymbolC*3, '$', yearEndBal, SymbolC*5, yearEndInt)
                print('2', SymbolC*3, '$', yearEndBal2, SymbolC*5, yearEndInt2)
                print('3', SymbolC*3, '$', yearEndBal3, SymbolC*5, yearEndInt3)

            elif numOfYears == 4:
                #Calculations for four years of change in year end ballance and year end interest. 

                #Next three lines are the same as the calculations from "if numOfYears == 1".
                interest = (InitialIA * monthly) * ((annualI / 100) / 12)
                yearEndBal = (InitialIA * monthly) + interest
                yearEndInt = interest

                #Next three lines are the same as the calculations from "if numOfYears == 2".
                interest2 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest
                yearEndBal2 = (InitialIA * monthly) + interest2 + yearEndBal
                yearEndInt2 = interest2 + interest

                #Next three lines are the same as the calculations from "if numOfYears == 3".
                interest3 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest2
                yearEndBal3 = (InitialIA * monthly) + interest3 + yearEndBal2
                yearEndInt3 = interest3 + interest2

                #Year end balance and interest calculations after four years of change in the balance.
                interest4 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest3 #"interest4" is the calculated interest for four years.
                yearEndBal4 = (InitialIA * monthly) + interest4 + yearEndBal3 #"yearEndBal4" is calculated year end balance for four years.
                yearEndInt4 = interest4 + interest3 #"yearEndInt4" is the calculated year end intest for four years.

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for four years of change.
                print('1', SymbolC*3, '$', yearEndBal, SymbolC*5, yearEndInt)
                print('2', SymbolC*3, '$', yearEndBal2, SymbolC*5, yearEndInt2)
                print('3', SymbolC*3, '$', yearEndBal3, SymbolC*5, yearEndInt3)
                print('4', SymbolC*3, '$', yearEndBal4, SymbolC*5, yearEndInt4)

            elif numOfYears == 5:
                #Calculations for five years of change in year end ballance and year end interest. 

                #Next three lines are the same as the calculations from "if numOfYears == 1".
                interest = (InitialIA * monthly) * ((annualI / 100) / 12)
                yearEndBal = (InitialIA * monthly) + interest
                yearEndInt = interest

                #Next three lines are the same as the calculations from "if numOfYears == 2".
                interest2 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest
                yearEndBal2 = (InitialIA * monthly) + interest2 + yearEndBal
                yearEndInt2 = interest2 + interest

                #Next three lines are the same as the calculations from "if numOfYears == 3".
                interest3 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest2
                yearEndBal3 = (InitialIA * monthly) + interest3 + yearEndBal2
                yearEndInt3 = interest3 + interest2

                #Next three lines are the same as the calculations from "if numOfYears == 4".
                interest4 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest3
                yearEndBal4 = (InitialIA * monthly) + interest4 + yearEndBal3
                yearEndInt4 = interest4 + interest3

                #Year end balance and interest calculations after five years of change in the balance.
                interest5 = (InitialIA * monthly) * ((annualI / 100) / 12) + interest4 #"interest5" is the calculated interest for five years.
                yearEndBal5 = (InitialIA * monthly) + interest5 + yearEndBal4 #"yearEndBal5" is calculated year end balance for five years.
                yearEndInt5 = interest5 + interest4 #"yearEndInt5" is the calculated year end intest for five years.

                #print statement bellow "Year, Year End Balance, and Year End Interst" in output display
                #for five years of change.
                print('1', SymbolC*3, '$', yearEndBal, SymbolC*5, yearEndInt)
                print('2', SymbolC*3, '$', yearEndBal2, SymbolC*5, yearEndInt2)
                print('3', SymbolC*3, '$', yearEndBal3, SymbolC*5, yearEndInt3)
                print('4', SymbolC*3, '$', yearEndBal4, SymbolC*5, yearEndInt4)
                print('5', SymbolC*3, '$', yearEndBal5, SymbolC*5, yearEndInt5)

            else:
                #In case the number of years entered exceeds five.
                print('Sorry. Invalid number of years.')
        except:
            #In case a bug or error in calculating the values occures. 
            print('Sorry, there was a problem claculating. Please try again')
    else:
        #If 0 is the input for the monthly deposit, this message prints, and the code under the previous if
        #statement "if monthly == 0" runs.
        print('No monthly Deposit')
    
    #Printing the last part of the output display.
    print(SymbolB*30)
    print(SymbolB*30)
    print('')

    #calls on quiting input function 
    user_input = Q_ToQuit()
