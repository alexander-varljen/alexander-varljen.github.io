README

-The txt file marked "artifcatthree" contains a text version of the MongoDB code used, in order, during the project

-The word document marked "CS 499 Artifact Three" is an APA style paper with screenshots of the code ran in the local
 Mongo Shell, along with explanations

-The CSV files marked "customers", "orders", and "rma" were the data sets used during the project