//===========================================================================================
// Name        : ePortfolio Artifact Two
// Author      : Alexander Varljen
// Date        : July 24, 2022
// Description : This ePortfolio artifact was an expansion of an earlier project, which was
// titled "CS 260 Data Structures and Algorithms: Hash Tables and Chaining", which was a 
// program which uploaded bid data from a csv file, placed the data into a hash table data 
// structure, and gave the user access to a menu with 4 different options other than Exit, 
// which where "Load bids", "Display all Bids", "Find Bid", and "Remove Bid". In this artifact,
// the program is expanded to include vector sorting capability, including a quick sort, and a
// selection sort, as well as four more user options, which load the bids to the sorting vector,
// diplays the bids in the sorting vector, sorts all the bids using a selection sort algorithm,
// and sorts all the bids using a quick sort algorithm.
//============================================================================================

#include <algorithm>
#include <climits>
#include <iostream>
#include <string> // atoi
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

const unsigned int DEFAULT_SIZE = 179;

// forward declarations
double strToDouble(string str, char ch);

// defines a structure to hold bid information for the hashed bids menu options (1-4)
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

// defines a structure to hold bid information for the vector sort menu options (5-8)
struct Bid2 {
	string bidId2; // unique identifier
	string title2;
	string fund2;
	double amount2;
	Bid2() {
		amount2 = 0.0;
	}
};

//#######################################################################
//                                                                      #
//METHODS FOR HASH TABLE DATA STRUCTURE AND MENU OPTIONS 1-4            #
//                                                                      #
//#######################################################################

//This defines the class containing the data members and methods that will be used to implement
//a hash table with chaining, which will store the bid data for the first four menu options
//(which are denoted by "option # <option> (Hased)"). 
class HashTable {

private:
    
	struct Node {
		Bid bid;
		unsigned key;
		Node* next;

		Node() {
			key = UNIT_MAX;
			next = nullptr;
		}

		Node(Bid aBid) : Node() {
			bid = aBid;
		}

		Node(Bid aBid, unsigned aKey) : Node(aBid) {
			key = aKey;
		}
	};

	vector<Node> nodes;
	unsigned tableSize = DEFAULT_SIZE;
    unsigned int hash(int key);

public:
    HashTable();
    HashTable(unsigned size);
    virtual ~HashTable();
    void Insert(Bid bid);
    void PrintAll();
    void Remove(string bidId);
    Bid Search(string bidId);
};

//This is the defult constructor for the hash table data structure for "Bids"
HashTable::HashTable() {
    
	nodes.resize(tableSize);

}

//defines the hash value of the Hash table data structure. 
HashTable::HashTable(unsigned size) {

	this->tableSize = size;
	nodes.resize(tableSize);

}

//Destructor to free storage when hash table class is destroyed.
HashTable::~HashTable() {
    
	nodes.erase(nodes.begin());

}

//Calculates the hash value of a given bid key in the "Bid" hash table data strucure.
unsigned int HashTable::hash(int key) {
    
	return key % tableSize;

}


//Function which inserts bids into the hash table data structure with a bid id key and node,
//and uses if statements and while loops to find the next slot to put the bid node.
void HashTable::Insert(Bid bid) {
    
	unsigned key = hash(strtol(bid.bidId.c_str()));
	Node* oldNode = &(nodes.at(key));

	if (oldNode == nullptr) {

		Node* newNode = new Node(bid, key);
		nodes.insert(nodes.begin() + key, (*newNode));

	} else {
		if (oldNode->key == UNIT_MAX) {

			oldNode->key = key;
			oldNode->bid = bid;
			oldNode->next = nullptr;

		} else {
			while (oldNode->next != nullptr) {

				oldNode = oldNode->next;

			}

			oldNode->next = new Node(bid, key);
		}
	}
}

//Function for the "Display All Bids (Hashed)" option in the menu, which iterates accross all
//of the bids stored in the hash table data structure.
void HashTable::PrintAll() {

	for (int i = 0; i < bid.size(); ++i) {
		displayBid(bid[i]);
	}
	cout << endl;

}


//Function called for the "Remove Bid (Hashed)" option on the menu, which erases a bid from
//the hash table data strucutre based on its bid id.
void HashTable::Remove(string bidId) {
    
	unsigned key = hash(strtol(bid.bidId.c_str()));
	nodes.erase(nodes.begin() + key, (*newNode));

}

//Funtion called for the "Find a bid (Hashed)" menu option, which searches for a bid in the hash
//table data structure by its Bid id.
Bid HashTable::Search(string bidId) {
    Bid bid;

    unsigned key = hash(strtol(bidId.c_str()));
    Node* node = &(nodes.at(key));

    if (node == nullptr || node->key == UNIT_MAX) {
    	return bid;
    }
    if (node != nullptr && node->key != UNIT_MAX && node->bid.bidId.compare(bidId) == 0) {
        return node->bid;
    }
    while (node != nullptr) {
    	if (node->key != UNIT_MAX && node->bid.bidId.compare(bidId)== 0) {
    		return node->bid;
    	}
    	node = node->next;
    }

    return bid;
}

//For the "Display Bid (Hashed)" menu option.
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
            << bid.fund << endl;
    return;
}

//Loads bids into the hash table for the first for menu options (which are denoted by "option # 
//<title> (Hashed)") from a csv file. 
void loadBids(string csvPath, HashTable* hashTable) {
    cout << "Loading CSV file " << csvPath << endl;

    // initializes the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // reads and displays header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loops to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Creates a data structure and adds to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            // pushes this bid to the end
            hashTable->Insert(bid);
        }
    } catch (csv::Error &e) {
		//catches errors while loading bids into the hash table data structure
        std::cerr << e.what() << std::endl;
    }
}

//################################################################
//                                                               #
//METHODS FOR VECTOR SORTING AND MENU OPTIONS 5-8                #
//                                                               #
//################################################################

//For option #6 in the menu, which prints out a bid in the "Bid2" vector, which is the data structure
//storing the bids for the "(Sorted)" options ("main" has a for loop that iterates this method 
//until all bids in the "Bid2" vector are printed).
void displayBid2(Bid2 bid2) {
	cout << bid2.bidId2 << ": " << bid2.title2 << " | " << bid2.amount2 << " | "
		<< bid2.fund2 << endl;
	return;
}

//User defined function which is called by "option 5. Load bids (Sorted)" and which loads bids 
//from the csv file into the data structure which will handle the "(Sorted)" options for the bids.
vector<Bid2> loadBids2(string csvPath) {
	cout << "Loading CSV file " << csvPath << endl;

	// Defines a vector data structure to hold a collection of bids for the vector sorting options.
	vector<Bid2> bids2;

	// Initializes the CSV Parser using the given path.
	csv::Parser file = csv::Parser(csvPath);

	try {
		// loops to read rows of a CSV file
		for (int i = 0; i < file.rowCount(); i++) {

			// Creates a data structure and adds to the collection of bids
			Bid2 bid2;
			bid2.bidId2 = file[i][1];
			bid2.title2 = file[i][0];
			bid2.fund2 = file[i][8];
			bid2.amount2 = strToDouble(file[i][4], '$');

			// pushes this bid to the end
			bids2.push_back(bid2);
		}
	}
	catch (csv::Error &e) {
		//Catches error in creating data structure.
		std::cerr << e.what() << std::endl;
	}
	return bids2;
}

//This is the user defined function which does the partitioning for the quick sort function,
//"quickSort". This partitions the vector into "low" and "high", and pivots to create a tree
//like structure for bid data storage in the "Bid2" vector. 
int partition(vector<Bid2>& bids2, int begin, int end) {
	//I completed the partition method for the quick sort methode by continually
	//partitioning and sorting the elements in the bids vector.
	int low = begin;
	int high = end;
	int pivot = begin + (end - begin) / 2;

	bool done = false;

	while (!done) {
		while (bids2.at(low).title2.compare(bids2.at(pivot).title2) < 0) {
			++low;
		}
		while (bids2.at(pivot).title2.compare(bids2.at(high).title2) < 0) {
			--high;
		}
		if (low >= high) {
			done = true;
		}
		else {
			swap(bids2.at(low), bids2.at(high));
		}
		++low;
		--high;
	}

	return high;
}

//"quickSort" is a user defined function that sorts all of the bids using a "qick sort" 
// vector sort. The average performance should be O(n log(n))
void quickSort(vector<Bid2>& bids2, int begin, int end) {

	if (begin < end) {

		int mid = partition(bids2, begin, end);
		quickSort(bids2, begin, mid - 1);
		quickSort(bids2, mid + 1, end);

	}
}

//"selectionSort" is a "selection sort" user defined function, which sorts the bids
//in ascending order with the average performance of O(N^2).
void selectionSort(vector<Bid2>& bids2) {
	
	int min;

	for (unsigned pos = 0; pos < bids2.size(); ++pos) {
		min = pos;
	}
	for (unsigned j = pos + 1; j < bids2.size(); ++j) {
		if (bids2.at(j).title2.compare(bids.at(min).title2) < 0) {
			min = j;
		}
	}
	if (min != pos) {
		swap(bids2.at(pos), bids2.at(min));
	}

}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}



 //The only main() method, with the user interface, and function calls.
int main(int argc, char* argv[]) {

    // These case locks process command line arguments
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98109";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv"; //csv file containing bid data
        bidKey = "98109";
    }

    // Defines a timer variable
    clock_t ticks;

    // Defines a hash table to hold all the bids (used for the "(Hashed)" options below)
    HashTable* bidTable;

	// Defines a vector to hold all the bids (used for the "(Sorted)" options below)
	vector<Bid2> bids2;

    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
		cout << "These first four options allow you to load 'Hashed' bids." << endl;
		cout << "These bids can then be found individually and removed individually." << endl;
        cout << "  1. Load Bids (Hashed)" << endl;
        cout << "  2. Display All Bids (Hashed)" << endl;
        cout << "  3. Find Bid (Hashed)" << endl;
        cout << "  4. Remove Bid (Hashed)" << endl;
		cout << "These next three options allow you to load 'Sorted' bids." << endl;
		cout << "These bids can then be sorted through a vector sort." << endl;
		cout << "  5. Load Bids (Sorted)" << endl;
		cout << "  6. Display All Bids (Sorted)" << endl;
		cout << "  7. Selection Sort All Bids (Sorted)" << endl;
		cout << "  8. Quick Sort All Bids (Sorted)"
		cout << "" << endl;
        cout << "  9. Exit" << endl;
		cout << "" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
			// Calls on the load bids function, which loads all of the bids from the
			// csv file into the hash table data structure.
            bidTable = new HashTable();

            // Initializes a timer variable before loading bids
            ticks = clock();

            // Method call to load the bids
            loadBids(csvPath, bidTable);

            // Calculates elapsed time and displays the results
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
			// Calls on the print all function, which prints all of the bids stored in the 
			//hash data structure.
            bidTable->PrintAll();
            break;

        case 3:
			// Calls on the search bid method for the bid storing hash data structure, finds the
			// bid, if present, and counts and displays the time it took to find the bid.
            ticks = clock();

            bid = bidTable->Search(bidKey);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!bid.bidId.empty()) {
                displayBid(bid);
            } else {
                cout << "Bid Id " << bidKey << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 4:
			// Calls on the remove bid function for the bid storing hash table.
            bidTable->Remove(bidKey);
            break;

		case 5:
			ticks = clock();

			// Completes the method call to load the bids into the sorting vector.
			bids = loadBids2(csvPath);

			// Tells user how many bids where read.
			cout << bids2.size() << " bids read" << endl;

			// Calculates the elapsed time and displays the results
			ticks = clock() - ticks;
			cout << "time: " << ticks << " clock ticks" << endl;
			cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

			break;

		case 6:
			//Calls on the display bids method for the vector storing the bid data that will 
			//be sorted, and loops and displays the bids read
			for (int i = 0; i < bids2.size(); ++i) {
				displayBid2(bids2[i]);
			}
			cout << endl;

			break;

		case 7:
			//Calls on the selection sort method and counts and displays the time the sort took.
			ticks = clock;
			selectionSort(bids2);

			cout << bids2.size() << " bids read" << endl;
			ticks = clock() - ticks;
			cout << "time: " << ticks << " clock ticks" << endl;
			cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl

			break;

		case 8:
			//Calls on the quick sort method and counts and displaysthe time the sort took.
			ticks = clock;
			quickSort(bids, 0, bids.size() - 1);

			cout << bids.size() << " bids read" << endl;
			ticks = clock() - ticks;
			cout << "time: " << ticks << " clock ticks" << endl;
			cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

			break;
			
        }
    }

    cout << "Good bye." << endl;

    return 0;
}
